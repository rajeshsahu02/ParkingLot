namespace ParkingLotAPI.Models;

public enum VehicleType
{
    TwoWheeler,
    FourWheeler,
    HeavyVehicle
}

public class ParkingSlot
{
    public int SlotNumber { get; set; }
    public VehicleType Type { get; set; }
    public bool IsOccupied { get; set; } = false;
}

public class ParkingTicket
{
    public string TicketId { get; set; } = Guid.NewGuid().ToString("N")[..8].ToUpper();
    public string VehicleNumber { get; set; } = string.Empty;
    public int SlotNumber { get; set; }
    public VehicleType VehicleType { get; set; }
    public DateTime InTime { get; set; } = DateTime.UtcNow;
    public DateTime? OutTime { get; set; }
}

// --- Request / Response DTOs ---

public class InitializeRequest
{
    public int TwoWheelerSlots { get; set; }   // M
    public int FourWheelerSlots { get; set; }  // N
    public int HeavyVehicleSlots { get; set; } // O
}

public class ParkRequest
{
    public string VehicleNumber { get; set; } = string.Empty;
    public VehicleType VehicleType { get; set; }
}

public class UnparkRequest
{
    public string TicketId { get; set; } = string.Empty;
}

public class ParkingLotDetails
{
    public SlotSummary TwoWheeler { get; set; } = new();
    public SlotSummary FourWheeler { get; set; } = new();
    public SlotSummary HeavyVehicle { get; set; } = new();
    public List<ParkingTicket> ActiveTickets { get; set; } = new();
}

public class SlotSummary
{
    public int Total { get; set; }
    public int Occupied { get; set; }
    public int Available => Total - Occupied;
}
