using ParkingLotAPI.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddSingleton<IParkingLotService, ParkingLotService>();

var app = builder.Build();

app.UseHttpsRedirection();
app.MapControllers();
app.Run();
