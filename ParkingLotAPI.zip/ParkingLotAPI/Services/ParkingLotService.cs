using ParkingLotAPI.Models;

namespace ParkingLotAPI.Services;

public interface IParkingLotService
{
    void Initialize(int twoWheeler, int fourWheeler, int heavyVehicle);
    ParkingLotDetails GetDetails();
    (ParkingTicket? ticket, string message) Park(string vehicleNumber, VehicleType vehicleType);
    (ParkingTicket? ticket, string message) Unpark(string ticketId);
    bool IsInitialized { get; }
}

public class ParkingLotService : IParkingLotService
{
    private List<ParkingSlot> _slots = new();
    private List<ParkingTicket> _activeTickets = new();
    private readonly object _lock = new();

    public bool IsInitialized => _slots.Count > 0;

    public void Initialize(int twoWheeler, int fourWheeler, int heavyVehicle)
    {
        lock (_lock)
        {
            _slots.Clear();
            _activeTickets.Clear();

            int slotNumber = 1;

            for (int i = 0; i < twoWheeler; i++)
                _slots.Add(new ParkingSlot { SlotNumber = slotNumber++, Type = VehicleType.TwoWheeler });

            for (int i = 0; i < fourWheeler; i++)
                _slots.Add(new ParkingSlot { SlotNumber = slotNumber++, Type = VehicleType.FourWheeler });

            for (int i = 0; i < heavyVehicle; i++)
                _slots.Add(new ParkingSlot { SlotNumber = slotNumber++, Type = VehicleType.HeavyVehicle });
        }
    }

    public ParkingLotDetails GetDetails()
    {
        lock (_lock)
        {
            var twoWheelerSlots   = _slots.Where(s => s.Type == VehicleType.TwoWheeler).ToList();
            var fourWheelerSlots  = _slots.Where(s => s.Type == VehicleType.FourWheeler).ToList();
            var heavyVehicleSlots = _slots.Where(s => s.Type == VehicleType.HeavyVehicle).ToList();

            return new ParkingLotDetails
            {
                TwoWheeler = new SlotSummary
                {
                    Total    = twoWheelerSlots.Count,
                    Occupied = twoWheelerSlots.Count(s => s.IsOccupied)
                },
                FourWheeler = new SlotSummary
                {
                    Total    = fourWheelerSlots.Count,
                    Occupied = fourWheelerSlots.Count(s => s.IsOccupied)
                },
                HeavyVehicle = new SlotSummary
                {
                    Total    = heavyVehicleSlots.Count,
                    Occupied = heavyVehicleSlots.Count(s => s.IsOccupied)
                },
                ActiveTickets = new List<ParkingTicket>(_activeTickets)
            };
        }
    }

    public (ParkingTicket? ticket, string message) Park(string vehicleNumber, VehicleType vehicleType)
    {
        lock (_lock)
        {
            if (!IsInitialized)
                return (null, "Parking lot is not initialized.");

            // Find first free slot for this vehicle type
            var slot = _slots.FirstOrDefault(s => s.Type == vehicleType && !s.IsOccupied);

            if (slot is null)
                return (null, $"No available slots for {vehicleType}. Parking refused.");

            slot.IsOccupied = true;

            var ticket = new ParkingTicket
            {
                VehicleNumber = vehicleNumber,
                SlotNumber    = slot.SlotNumber,
                VehicleType   = vehicleType,
                InTime        = DateTime.UtcNow
            };

            _activeTickets.Add(ticket);
            return (ticket, "Vehicle parked successfully.");
        }
    }

    public (ParkingTicket? ticket, string message) Unpark(string ticketId)
    {
        lock (_lock)
        {
            var ticket = _activeTickets.FirstOrDefault(t => t.TicketId == ticketId);

            if (ticket is null)
                return (null, "Ticket not found.");

            var slot = _slots.FirstOrDefault(s => s.SlotNumber == ticket.SlotNumber);
            if (slot is not null)
                slot.IsOccupied = false;

            ticket.OutTime = DateTime.UtcNow;
            _activeTickets.Remove(ticket);

            return (ticket, "Vehicle unparked successfully.");
        }
    }
}
