using Microsoft.AspNetCore.Mvc;
using ParkingLotAPI.Models;
using ParkingLotAPI.Services;

namespace ParkingLotAPI.Controllers;

[ApiController]
[Route("api/parkinglot")]
public class ParkingLotController : ControllerBase
{
    private readonly IParkingLotService _parkingService;

    public ParkingLotController(IParkingLotService parkingService)
    {
        _parkingService = parkingService;
    }

    // POST /api/parkinglot/initialize
    [HttpPost("initialize")]
    public IActionResult Initialize([FromBody] InitializeRequest request)
    {
        if (request.TwoWheelerSlots < 0 || request.FourWheelerSlots < 0 || request.HeavyVehicleSlots < 0)
            return BadRequest(new { message = "Slot counts must be non-negative." });

        _parkingService.Initialize(
            request.TwoWheelerSlots,
            request.FourWheelerSlots,
            request.HeavyVehicleSlots
        );

        return Ok(new
        {
            message = "Parking lot initialized successfully.",
            twoWheelerSlots   = request.TwoWheelerSlots,
            fourWheelerSlots  = request.FourWheelerSlots,
            heavyVehicleSlots = request.HeavyVehicleSlots
        });
    }

    // GET /api/parkinglot/details
    [HttpGet("details")]
    public IActionResult GetDetails()
    {
        if (!_parkingService.IsInitialized)
            return BadRequest(new { message = "Parking lot is not initialized yet." });

        var details = _parkingService.GetDetails();
        return Ok(details);
    }

    // POST /api/parkinglot/park
    [HttpPost("park")]
    public IActionResult Park([FromBody] ParkRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.VehicleNumber))
            return BadRequest(new { message = "Vehicle number is required." });

        var (ticket, message) = _parkingService.Park(request.VehicleNumber, request.VehicleType);

        if (ticket is null)
            return Conflict(new { message });

        return Ok(new { message, ticket });
    }

    // POST /api/parkinglot/unpark
    [HttpPost("unpark")]
    public IActionResult Unpark([FromBody] UnparkRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.TicketId))
            return BadRequest(new { message = "Ticket ID is required." });

        var (ticket, message) = _parkingService.Unpark(request.TicketId);

        if (ticket is null)
            return NotFound(new { message });

        return Ok(new { message, ticket });
    }
}
