using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;

[Route("api/home"]
[ApiController]
public class HomeController : ControllerBase
{
    [HttpPost("parkingLot/Intialize")]
    public IActionResult Initialize()
    {
        var result = ParkingService.Initilize();
        return Ok();
    }

    [HttpGet("parkingLot/details")]
    public IActionResult Details()
    {
        var result  = ParkingService.Details();
        return Ok();
    }

    [HttpPost("parkingLot/park")]
    public IActionResult Park([FromBody] VehicleType vehicle)
    {
        var result = ParkingService.Park(vehicle);
        return Ok();
    }

    [HttpPost("parkingLot/unpark")]
    public IActionResult Unpark([FromBody] string Number)
    {
        var result = ParkingService.Unpark(Number);
        return Ok();
    }
    
}