public class ParkingService : IParkingService
{
    List<ParkingSpot> spots = new List<ParkingSpot>();
    List<Ticket> tickets = new List<Ticket>();

    public ParkingService()
    {

        int Sid = 1;
        int m = 2, n = 2, o = 2;
        for (int i = 0; i < m; i++)
        {
            ParkingSpot sp = new ParkingSpot();
            sp.SpotId = Sid++;
            sp.Type = VehicleType.TwoVehiler;
            spots.Add(sp);
        }
        for (int i = 0; i < n; i++)
        {
            spots.Add(new ParkingSpot() {SpotId = Sid++, Type = VehicleType.FourVehiler, IsOccupiad = false });
        }
        for (int i = 0; i < o; i++)
        {
            spots.Add(new ParkingSpot()  { SpotId = Sid++, Type = VehicleType.HeavyVehicle, ParkedVehicle = null, IsOccupiad = false });
        }
    }

    public string Park(Vehicle vehicle)
    {
        ParkingSpot spot = spots.FirstOrDefault(s => !s.IsOccupiad && Type == vehicle.Type);
        if (spot == null) return "No occupancy";
        spot.ParkedVehicle = vehicle;
        return "Parked at {spot.Id}";

    }
    public string Unpaark(Vehicle vehicle)
    {
        ParkingSpot spot = spots.FirstOrDefault(s => !s.IsOccupiad && Type == vehicle.Type);
        if (spot == null) return "No occupancy";
        spot.ParkedVehicle = vehicle;
        return "Parked at {spot.Id}";

    }
    public string Deatils(Vehicle vehicle)
    {

    }

}