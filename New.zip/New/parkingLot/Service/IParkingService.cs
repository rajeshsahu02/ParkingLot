public interface IParkingService
{
    string Park();
    string Unpark();
    List<ParkingSpot> details();
    void initial();

}