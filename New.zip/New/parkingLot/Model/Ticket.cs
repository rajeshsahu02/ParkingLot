public class Ticket
{
    public int Id {get; set;}
    public string VehicleNumber {get; set;}
    public int SpotId {get; set;}
    public DateTime EntryTime {get; set;}
    public DateTime ExitTime {get; set;}
}