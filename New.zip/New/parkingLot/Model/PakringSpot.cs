public class ParkingSpot
{
    public int SpotId {get; set;}
    public VehicleType Type {get; set;}
    public Vehicle? ParkedVehicle {get; set;} 
    public bool IsOccupiad {get; set;}
}