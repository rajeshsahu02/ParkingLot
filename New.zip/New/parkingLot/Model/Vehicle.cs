public enum VehicleType{
    TwoVehiler,
    FourVehiler,
    HeavyVehicle
}
public class Vehicle
{
    public string VehicleNumber {get; set;}
    public VehicleType Type {get; set;}
}